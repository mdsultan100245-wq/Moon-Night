MOON NIGHT — Free starter fashion store

FILES
- index.html: the website. Open it in a browser to preview.

HOW IT WORKS
- Product cards, category filters, search, cart, and order form work in the browser.
- The checkout prepares an order message and opens WhatsApp.
- The payment number shown is 01627495659.
- This is a starter storefront, not a payment gateway or inventory database. Orders are not saved to a server and payment is not automatically processed.
- The WhatsApp order destination is set to 8801627495659. If that number is not connected to WhatsApp, change `whatsappNumber` near the bottom of index.html to the shop's WhatsApp number (country code 880, without the leading 0).
- Product names, prices, images and delivery rules are sample content. Update them before launching. The demo images load from Unsplash and need an internet connection.

FREE HOSTING
Option: GitHub Pages (free for public repositories)
1. Sign in to GitHub and create a new PUBLIC repository named moon-night-store.
2. Upload index.html from this folder to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
4. Wait for GitHub to publish the site. Your free address will look like https://YOUR-USERNAME.github.io/moon-night-store/
5. Test the site on a phone before sharing it with customers.

No custom domain is included; a custom .com domain normally costs money.
